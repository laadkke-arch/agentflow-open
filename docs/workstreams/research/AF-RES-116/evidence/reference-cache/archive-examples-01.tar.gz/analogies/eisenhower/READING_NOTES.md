# Eisenhower 원문 판독 보완 기록

보조 조사자: `/root/cross_domain` AI. 실제 판독 UTC는 `visual-readings.jsonl`과 AN-S059·060·064·065에 있다. 자연 요청·꾸러미·정답표·수신 기록 노출은 0이다. PDF 스킬을 읽고 Poppler로 원문 페이지를 렌더한 뒤 실제 이미지 출력을 보았다.

## 위치에서 원 항목까지

발행자 [Farewell Address 항목 안내](https://www.eisenhowerlibrary.gov/research/online-documents/farewell-address)의 Reading copy와 January 17, 1961 Press release는 모두 **DDE Papers as President / Speech Series / Box 38 / Final TV Talk (1)**에 속한다. 하지만 항목 식별자는 각각 **NAID 594599**와 **NAID 16972219**다. 안내의 연결을 클릭해서 공식 PDF에 도달했으며 임의로 원문 URL을 추정한 것이 아니다. [주제별 finding guide](https://www.eisenhowerlibrary.gov/sites/default/files/research/subject-guides/pdf/farewell-address-january-17-1961.pdf) 1쪽은 Box 38 / Final TV Talk (1)–(3)에 보도자료·주석 낭독본·초안 8종이 함께 포함됨을 기술한다. 이 finding guide 말미의 발행 표지는 VJA 11/2010이다.

| 직접 본 페이지 | 관측 | 한계 |
| --- | --- | --- |
| `reading-copy.pdf`, PDF 1쪽 / `reading-copy-page01.png` | 펀치 구멍이 있는 종이에 인사말과 방송망에 대한 감사 도입문. 타자문과 여러 삽입·삭제가 겹쳐 있다. “must” 위에 “should like to” 수정이 보인다. | 출판자가 낭독본으로 기술한 원문이다. 개별 필적의 작성자를 감정하지 않았다. |
| 같은 PDF 2쪽 / `reading-copy-page02.png` | 위쪽 감사문이 손글씨로 남아 지워져 있고, 아래 타자문 본문은 “THREE DAYS from now”로 시작한다. 여러 밑줄·삭제 흔적이 보인다. | 전체 27쪽 중 1–2쪽만 판독했다. 실제 방송 오디오와 일치 여부는 조사하지 않았다. |
| `1961-01-17-press-release.pdf`, 1쪽 / `press-release-page01.png` | White House·James C. Hagerty·1961-01-17 release 표지. 인사말 다음 본문은 “Three days from now”로 시작한다. 이 페이지에는 낭독본 1쪽의 별도 감사 도입문과 수정 흔적이 보이지 않는다. | 전체 4쪽의 손수정 유무를 일반화하지 않는다. 낭독본과 동일한 연설의 다른 원 항목/판이다. |
| `subject-guide.pdf`, 1쪽 / `subject-guide-page01.png` | 상자 38의 포함 항목 설명과 별도 상자 665의 보도자료 사본 표지를 시각 확인했다. | finding guide는 원 연설의 내용 증거가 아니라 위치·형태 기술의 증거다. |

위 비교로 확인한 범위는 **같은 상자·폴더·연설 제목이 곧 동일한 원 항목은 아니며, 수정 흔적이나 도입문을 묻는 요청에는 판 구별이 필요하다**는 점이다. 어느 쪽이 실제 방송에서 말해졌는지나 모든 문장의 차이를 확정하지 않는다. 낭독본·보도자료를 고유 저작 두 개로 부풀리지 않고 한 연설 저작의 두 원 기록으로 산입했다.

## 읽은 것과 못 읽은 것

웹 PDF 파서는 낭독본·보도자료·1월 7일 초안에서 추출 본문 0행을 반환했다(AN-S054–056). 이는 문서 내용 판독으로 인정하지 않았다. 낭독본과 보도자료만 직접 HTTP로 내려받고 렌더했다. 1월 7일 초안은 원문 내용 미열람이다. Yale의 항목 레코드→원 편지 403 및 공개 API 실패는 AN-S040·050에 그대로 보존되어 있다. 이 사례가 그 편지의 내용을 대신 증명하지 않는다.

추가로 [FDR Library·Center for Legislative Archives 공동 성명](https://www.fdrlibrary.org/documents/356632/390886/statement_infamy/d8ba092a-819d-452c-bd7e-461bf3bfab44) 3–5쪽을 읽었다. 이 성명은 손수정이 있는 Senate copy를 낭독본으로 여긴 기존 식별에 반박하면서, 별도 House copy·문서 형식·기록 계보를 함께 검토해야 한다고 설명한다. 여기서 판독한 것은 **기관의 반증 성명**이다. 원 상·하원 사본과 회고록을 직접 읽어 역사적 판단을 독립 재검증한 것으로 기록하지 않았다. 성명 발행일과 현재 유실 상태도 별도로 확인하지 않았다.

## 보존된 입력과 재현

작업 디렉터리는 저장소 루트다. PDF 자체와 렌더가 이미 보존되어 있으므로 네트워크 접근 없이도 같은 페이지를 열 수 있다. 파일 지문과 내려받기 시작 UTC·실측 경과는 `download-receipts.jsonl`에 있다.

```bash
pdftoppm -f 1 -l 1 -scale-to 1600 -png -singlefile docs/workstreams/research/AF-RES-116/analogies/eisenhower/reading-copy.pdf docs/workstreams/research/AF-RES-116/analogies/eisenhower/reading-copy-page01
pdftoppm -f 2 -l 2 -scale-to 1600 -png -singlefile docs/workstreams/research/AF-RES-116/analogies/eisenhower/reading-copy.pdf docs/workstreams/research/AF-RES-116/analogies/eisenhower/reading-copy-page02
pdftoppm -f 1 -l 1 -scale-to 1600 -png -singlefile docs/workstreams/research/AF-RES-116/analogies/eisenhower/1961-01-17-press-release.pdf docs/workstreams/research/AF-RES-116/analogies/eisenhower/press-release-page01
pdftoppm -f 1 -l 1 -scale-to 1600 -png -singlefile docs/workstreams/research/AF-RES-116/analogies/eisenhower/subject-guide.pdf docs/workstreams/research/AF-RES-116/analogies/eisenhower/subject-guide-page01
```

이 명령들은 실제 실행되었고, 출력 PNG 네 개를 직접 보았다. 파일을 읽을 때 `pdftotext` 추출 성공만으로 원 페이지를 봤다고 처리하면 안 된다. 페이지 2와 guide 1쪽의 최초 이미지 요청은 문맥 압축 뒤 결과가 보존되지 않아 AN-S062·063에서 시도만 기록하고 재개봉 AN-S064·065에 실제 확인을 두었다.

다운로드 성공 세 건의 6,416,882바이트와 약 27.7643초는 HTTP 수신량·수신 경과다. 사람의 읽기·준비 시간이나 효율은 관측하지 않았다. 모든 비교는 보조층이고 자연 표본 성공 분모·18꾸러미·54단계에 더하지 않는다.

| 가장 중요한 불일치·약점 | 다음 조사·직접 열 자료 | 어떤 관측이면 판단이 바뀌나 |
| --- | --- | --- |
| 같은 폴더의 두 판이 실제로 다르다는 것은 3쪽 직접 판독으로 확인했지만 전체 연설과 방송은 비교하지 않았다. | 보존된 낭독본 나머지 쪽·보도자료·공식 방송 오디오를 연다. | 특정 요청 속성에 관해 두 판이 완전히 동등하면 그 요청에는 판 구별의 필요를 좁힌다. |
| Yale 원 편지는 여전히 미열람이며 FDR 비교는 발행자 성명에 한정한다. | Yale catalog 32337608 image 9/104 또는 FDR Senate/House 원본을 연다. | 원본이 목록/성명의 대응과 어긋나면 해당 설명을 정정한다. |
| 안내의 실제 수신 효과와 독립 인간 판단은 관측하지 않았다. | 별도로 봉인한 자연 실험의 실제 노출과 단계별 판단을 검토한다. | 같은 노출 예산에서 정확한 조건·반례 판독이 달라졌다는 독립 관측이 있어야 효과를 추가한다. |
